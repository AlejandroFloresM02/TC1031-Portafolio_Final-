//Abraham de Alba
//Alejandro Flores
//Diego Rosas

class Solution {
public:
    bool isPalindrome(int x) {
        if(x <= 0) {
            return x == 0;
        }
        
        string xString = to_string(x);
        int indiceInf = 0;
        int indiceSup = xString.size() - 1;
        
        while(indiceInf < indiceSup) {
            if(xString[indiceInf] != xString[indiceSup]) {
                return false;
            }
            indiceInf++;
            indiceSup--;
        }
    
        return true;
        
    }
};