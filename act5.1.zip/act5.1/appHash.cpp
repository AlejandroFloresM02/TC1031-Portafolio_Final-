#include <iostream>
#include "tabla_hash.h"

using namespace std;

void Quadratic(tabla_hash tabla, vector<int> arr){
    for(int i=0; i< arr.size(); i++){
        int inKey = arr[i] %15;
        int newKey = inKey;
        int num =1;
        while (tabla.arrKeys[newKey]->next && newKey < 100){
            newKey = inKey + num * num;
            num = num +1;
        }
        if(newKey >= 100){
            cout << "Limite excedidio" << endl;
        }
        else{
            Node* temp = new Node(arr[i],NULL);
            tabla.arrKeys[newKey]->next = temp;
        }
    }
}

void chain(tabla_hash tabla, vector<int> arr ){
    for (int i=0; i<arr.size();i++){
        int key = arr[i] %15;
        Node* temp = new Node (arr[i], NULL);
        Node* prev = new Node;
        prev = tabla.arrKeys[key];

        while(prev->next){
            prev = prev->next;
        }
        prev->next = temp;
    }
}

int main(){
    tabla_hash test1;
    vector<int> vect {10,45,5,24,11,1,2,3,68,5,4,8,44,15,16,17};
    chain(test1, vect);
    test1.print();
}