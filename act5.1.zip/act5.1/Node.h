#ifndef NODE_H
#define NODE_H
#include <stdio.h>

using namespace std;

class Node{
    public: 
        int data; 
        Node* next;

        Node();
        Node(int, Node*);
        void set_data(int);
        void set_next(Node*);
};

Node::Node(){
    next = NULL;
}

Node::Node(int _data, Node* _next){
    next = _next;
    data = _data; 
}

void Node::set_data(int new_data){
    this->data = new_data;
}

void Node::set_next(Node* next_node){
    this->next = next_node;
}

#endif