#ifndef TABLA_HASH_H
#define TABLA_HASH_H
#include "Node.h"
#include <vector>
#include <iostream>

using namespace std; 

class tabla_hash{
    public:
        int size = 100;
        Node* arrKeys [100];

        tabla_hash(){
            for(int i=0;i<100;i++){
                Node* temp = new Node;
                temp->set_data(i);
                arrKeys[i] = temp; 
            }
        }

        void insert(Node* node, int data){
            Node* next_node = new Node(data, NULL);
            node->next = next_node;
        }

        void print(){
            for(int i=0;i<100;i++){
                Node* temp = new Node;
                temp = arrKeys[i];
                cout << arrKeys[i]->data;
                while(temp->next){
                    cout<<" - "<< temp->next->data;
                    temp = temp->next;
                } 
                cout << "\n";
            }
        }
};


#endif